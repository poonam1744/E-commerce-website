


<!---footer start--->

<br>
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 text-center">
        <img src="img/logo.png" class="footer-img">
        <p>Lorem ipsum dolor sit amet <br>
       consectetur adipiscing elit.<br>
       Lorem ipsum dolor sit amet</p>
        <img src="img/social.png">
        
      </div>
      <span id="footer-line"></span>
      <div class="col-lg-3 text-center">
        
        <h5 class="footer-header">my account</h5>
        <p>Lorem ipsum<br>
        Lorem ipsum<br>
        Lorem ipsum<br>
        Lorem ipsum<br>
        Lorem ipsum<br>
        Lorem ipsum<br>
        Lorem ipsum</p>
        
      </div>
       <span  id="footer-line"></span>
      <div class="col-lg-4 text-center">

       <h5 class="footer-header">Shop</h5>

      <p>Lorem ipsum<br>
      Lorem ipsum<br>
      Lorem ipsum<br>
      Lorem ipsum<br>
      Lorem ipsum<br>
      Lorem ipsum</p>
        
        
      </div>

      
    </div>
  </div>
</div>


<!---footer end--->
<br>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <span id="last-footer-line"></span>
    </div>
    <div class="col-md-12 text-center">
      <img src="img/footerful.png" class="last-pic">
    </div>
  </div>
</div>
<br>

<!---footer line--->
<!---<div class="footer1">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <p>Site Map  Search Terms  Advanced Search Orders and Returns  Contact Us</p>
        <p>© 2022 FashionStore. All Rights Reserved.</p>
        <img src="img/pay.png" class="img-fluid">
      </div>
    </div>
  </div>
</div>--->


<!---footer line--->





  

 



  <script src="https://kit.fontawesome.com/3b83a3096d.js" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <script src="js/isotope.js"></script>
  <script src="js/isotope-active.js"></script>

</body>
</html>